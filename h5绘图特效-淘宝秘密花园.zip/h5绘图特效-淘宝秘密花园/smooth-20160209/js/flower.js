var canvas = document.getElementById('canvas');
//var canvas = document.getElementsByClassName('sketch');

canvas.addEventListener("mousedown", doMouseDown, false);
w = canvas.width = window.innerWidth;
h = canvas.height = window.innerHeight;
ctx = canvas.getContext('2d');



//背景颜色黑
//$("#canvas").css("background","#000");

//global variables全局变量
var fps = 10;
var interval = 1000 / fps;
var frame = 0;
var sf = Math.min(w,h)/1.5; //scale factor比例系数
var grd=ctx.createRadialGradient(w/2,h/2,0,w/2,h/2,sf*1.2);  //创建放射状/圆形渐变对象

//背景色
//渐变彩色背景
//grd.addColorStop(0,"rgba(255,255,255,.25)");
//grd.addColorStop(1,cb(rand(200,255),rand(200,255),rand(200,255),25));

//渐变色变成单一黑色背景
grd.addColorStop(0,"#000");
grd.addColorStop(1,"#000");



//flowers!
var num_flowers = 7;
var fs = [];
for (var i = 0; i < num_flowers; i++){
    fs.push({size:rand(1,2),petals:rand(4,8),rot:rand(-5,5),c:[rand(100,255),rand(100,255),rand(100,255)],x:w/2,y:h/2});
}

fs.sort(function(a,b) { return parseFloat(b.size) - parseFloat(a.size) } );

draw();
function draw() {
    setTimeout(function() {
        window.requestAnimationFrame(draw);
        frame+=1;
        
        //clear canvas
        ctx.shadowBlur = 0;
        ctx.fillStyle = grd;
        ctx.fillRect(0,0,w,h);
        
        for (var i = 0; i < num_flowers; i++){
            draw_flower(sf*fs[i].size/10, fs[i].petals*2, 0,fs[i].rot/4,fs[i].c,fs[i].x,fs[i].y);  //rot的分母越小，旋转速度越快初始为15
        }

        
        
        
    }, interval);
}

function cb(r, g, b, o) {
    return "rgba(" + r + "," + g + "," + b + "," + o + ")";
}

function add_flower(_x,_y){
    fs.push({size:rand(1,5),petals:rand(4,6),rot:rand(-15,15),c:[rand(100,255),rand(100,255),rand(100,255)],x:_x,y:_y});
	
    num_flowers++;
	
	//以下自己添加
	//setInterval(clear,5000);
}

function draw_flower(_rad, _num_pts, init_angle, spin_vel,c,_x,_y){
    
    ctx.shadowBlur = 0;
    ctx.lineWidth = 1;
	ctx.shadowColor = cb(c[0],c[1],c[2],1);
	//ctx.fillStyle = cb(c[0],c[1],c[2],.6); //透明度0.6
	ctx.fillStyle = cb(c[0],c[1],c[2],0.8); //透明度0.8
    c2 = [Math.floor(c[0]/1.6),Math.floor(c[1]/1.6),Math.floor(c[2]/1.6)];
    
	ctx.strokeStyle = cb(c2[0],c2[1],c2[2],1);
    
        var pts = [];
        for (var i = 0 ; i <= _num_pts ; i++){
            var _a = (360/_num_pts) * i + init_angle + frame*spin_vel;
                
            pts.push({x:P2L(_rad, _a).x,y:P2L(_rad, _a).y});  
        }

        for (var i = 1 ; i<= _num_pts; i+=2){
            idx= i%_num_pts;
            ctx.beginPath();
            ctx.moveTo(_x,_y);
			//绘制曲线
            ctx.bezierCurveTo(_x+pts[i-1].x,_y+pts[i-1].y,_x+pts[idx+1].x,_y+pts[idx+1].y,_x,_y);
            ctx.stroke();
            ctx.fill();
        }
}

function rand(min, max){
    return Math.round(Math.random() * (max - min) + min);
}

//polar to linear coordinate transform极坐标变换 
function P2L(r, angle){
    var ret = {x:0, y:0};
    ret.x = Math.cos(angle*Math.PI/180)*r;
    ret.y = Math.sin(angle*Math.PI/180)*r;
    return (ret);
}

function doMouseDown(event){
    var totalOffsetX = 0;
    var totalOffsetY = 0;
    var canvasX = 0;
    var canvasY = 0;
    var currentElement = this;

    do{
        totalOffsetX += currentElement.offsetLeft - currentElement.scrollLeft;
        totalOffsetY += currentElement.offsetTop - currentElement.scrollTop;
    }
    while(currentElement = currentElement.offsetParent)

    canvasX = event.pageX - totalOffsetX;
    canvasY = event.pageY - totalOffsetY;

    add_flower(canvasX,canvasY)
	
}






//以下是自己添加


function clear(){
	
	
}
